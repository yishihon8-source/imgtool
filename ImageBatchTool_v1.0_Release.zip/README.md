# 图片批处理工具 (Image Batch Tool)

专业的图片批处理工具，支持 Photoshop 风格的变换和选区功能。

## ✨ 主要特性

- ✅ **支持中文文件名** - 完美处理 UTF-8/Unicode 路径
- ✅ **Photoshop 风格变换** - Ctrl+T 进入变换模式，支持拖拽、缩放、对齐
- ✅ **选区工具** - M 键进入选区模式，支持删除、撤销/重做
- ✅ **批处理缓存** - 自动保存修改，批处理时应用所有调整
- ✅ **智能对齐** - 自动显示辅助线，精确对齐
- ✅ **多种缩放模式** - 适应、填充、拉伸、原始尺寸

## 🚀 快速开始

1. 下载 `ImageBatchTool.exe`
2. 双击运行（无需安装）
3. 导入图片 → 设置画布 → 应用画布 → 开始批处理

## ⌨️ 快捷键

| 功能 | 快捷键 |
|------|--------|
| 变换模式 | `Ctrl + T` |
| 选区模式 | `M` |
| 删除选区 | `Delete` / `Backspace` |
| 撤销 | `Ctrl + Z` |
| 重做 | `Ctrl + Shift + Z` |
| 缩放画布 | `Alt + 滚轮` |
| 移动画布 | `空格 + 拖拽` |

## 📦 下载

- [最新版本](https://github.com/yishihon8-source/imgtool/releases)
- [源代码](https://github.com/yishihon8-source/imgtool)

## 🛠️ 技术栈

- **语言**: C++17
- **GUI**: Dear ImGui
- **图形**: OpenGL 3.3
- **图像处理**: STB Image
- **构建系统**: CMake + Ninja

## 📋 系统要求

- Windows 10/11 (64位)
- 内存: 4GB+
- 显卡: 支持 OpenGL 3.0+

## 🔧 从源码编译

```bash
# 克隆仓库
git clone https://github.com/yishihon8-source/imgtool.git
cd imgtool

# 配置和编译
cmake -B build -G Ninja
cmake --build build --config Release

# 运行
./build/bin/ImageBatchTool.exe
```

## 📝 使用说明

详细使用说明请查看 [使用说明.txt](./使用说明.txt)

## 🐛 问题反馈

如果遇到问题，请在 [GitHub Issues](https://github.com/yishihon8-source/imgtool/issues) 提交反馈。

## 📄 许可证

MIT License

## 🙏 致谢

- [Dear ImGui](https://github.com/ocornut/imgui) - GUI 框架
- [GLFW](https://www.glfw.org/) - 窗口管理
- [STB](https://github.com/nothings/stb) - 图像加载

---

**版本**: v1.0  
**更新日期**: 2026-02-05

